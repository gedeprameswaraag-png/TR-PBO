package poskasirapp;

import Ui.PosFrame;
import javax.swing.SwingUtilities;

public class POSKasirApp {
    public static void main(String[] args) {

        // jalankan UI
        SwingUtilities.invokeLater(() -> {
            PosFrame frame = new PosFrame();
            frame.setVisible(true);
        });
    }
}
