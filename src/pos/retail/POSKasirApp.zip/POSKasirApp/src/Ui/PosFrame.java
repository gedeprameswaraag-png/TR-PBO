package Ui;

import Dao.ProductDao;
import Model.Product;
import Model.TransactionItem;
import Service.Service;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class PosFrame extends JFrame {
    private JTextField txtSku;
    private JButton btnAdd;
    private JTable tblCart;
    private DefaultTableModel cartModel;
    private JLabel lblTotal;
    private JButton btnCheckout;
    private JButton btnRemove;

    private List<TransactionItem> cart = new ArrayList<>();
    private ProductDao productDao = new ProductDao();
    private Service posService = new Service();

    public PosFrame() {
        setTitle("POS - Kasir");
        setSize(950,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        // Top panel: scan input
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtSku = new JTextField(25);
        btnAdd = new JButton("Tambah (Enter)");
        top.add(new JLabel("Scan / SKU:"));
        top.add(txtSku);
        top.add(btnAdd);
        getContentPane().add(top, BorderLayout.NORTH);

        // Center: table cart
        cartModel = new DefaultTableModel(new Object[]{"SKU","Nama","Qty","Harga","Subtotal"},0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tblCart = new JTable(cartModel);
        JScrollPane sp = new JScrollPane(tblCart);
        getContentPane().add(sp, BorderLayout.CENTER);

        // Right: summary & actions
        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        lblTotal = new JLabel("Total: Rp 0");
        lblTotal.setFont(new Font("SansSerif", Font.BOLD, 18));
        right.add(lblTotal);
        right.add(Box.createVerticalStrut(10));

        btnCheckout = new JButton("Checkout Tunai");
        btnRemove = new JButton("Hapus Item");
        btnRemove.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCheckout.setAlignmentX(Component.CENTER_ALIGNMENT);
        right.add(btnRemove);
        right.add(Box.createVerticalStrut(8));
        right.add(btnCheckout);
        right.add(Box.createVerticalGlue());
        getContentPane().add(right, BorderLayout.EAST);

        // Actions
        btnAdd.addActionListener(e -> addSku());
        txtSku.addActionListener(e -> addSku());

        // double click row -> change qty
        tblCart.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int r = tblCart.getSelectedRow();
                    if (r >= 0) {
                        TransactionItem it = cart.get(r);
                        String s = JOptionPane.showInputDialog(PosFrame.this, "Ubah qty untuk " + it.getSku(), it.getQty());
                        try {
                            int q = Integer.parseInt(s);
                            if (q > 0) { it.setQty(q); refreshCart(); }
                        } catch (Exception ex) { /* ignore invalid input */ }
                    }
                }
            }
        });

        // Remove selected item
        btnRemove.addActionListener(e -> {
            int r = tblCart.getSelectedRow();
            if (r >= 0) {
                cart.remove(r);
                refreshCart();
            } else {
                JOptionPane.showMessageDialog(this, "Pilih item yang ingin dihapus.");
            }
        });

        btnCheckout.addActionListener(e -> doCheckout());
    }

    private void addSku() {
        String sku = txtSku.getText().trim();
        if (sku.isEmpty()) return;

        Product p = productDao.findBySku(sku);
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Produk tidak ditemukan: " + sku);
            txtSku.selectAll();
            txtSku.requestFocus();
            return;
        }

        // check existing in cart
        TransactionItem found = null;
        for (TransactionItem it : cart) if (it.getSku().equals(p.getSku())) { found = it; break; }
        if (found != null) { found.setQty(found.getQty() + 1); }
        else { cart.add(new TransactionItem(p.getId(), p.getSku(), p.getName(), 1, p.getPrice())); }

        refreshCart();
        txtSku.setText("");
        txtSku.requestFocus();
    }

    private void refreshCart() {
        cartModel.setRowCount(0);
        double total = 0;
        DecimalFormat df = new DecimalFormat("#,###");
        for (TransactionItem it : cart) {
            cartModel.addRow(new Object[]{it.getSku(), it.getName(), it.getQty(), df.format(it.getUnitPrice()), df.format(it.getSubtotal())});
            total += it.getSubtotal();
        }
        lblTotal.setText(String.format("Total: Rp %s", df.format(total)));
    }

    private void doCheckout() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Keranjang kosong");
            return;
        }

        String sCash = JOptionPane.showInputDialog(this, "Masukkan tunai:");
        if (sCash == null) return; // cancel

        double cash;
        try {
            // remove non-digits (allow thousand separators)
            sCash = sCash.replaceAll("[^0-9.]", "");
            cash = Double.parseDouble(sCash);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Format tunai salah");
            return;
        }

        try {
            // Using demo userId = 1 (kasir) — sesuaikan bila ada sistem login
            posService.processCheckout(1, cart, 0.0, 0.0, "TUNAI", cash);
            JOptionPane.showMessageDialog(this, "Checkout berhasil!");
            cart.clear();
            refreshCart();
        } catch (IllegalArgumentException ia) {
            JOptionPane.showMessageDialog(this, ia.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saat checkout: " + ex.getMessage());
            ex.printStackTrace();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Gagal: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
