package Ui;

import javax.swing.SwingUtilities;

public class PosMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PosFrame f = new PosFrame();
            f.setVisible(true);
        });
    }
}
