package Ui;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField txtUser;
    private JPasswordField txtPass;
    private JButton btnLogin;

    public LoginFrame() {
        setTitle("Login - POS Kasir");
        setSize(350, 180);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(new JLabel("Username:"));
        txtUser = new JTextField();
        panel.add(txtUser);

        panel.add(new JLabel("Password:"));
        txtPass = new JPasswordField();
        panel.add(txtPass);

        btnLogin = new JButton("Login");
        panel.add(new JLabel()); // kosong
        panel.add(btnLogin);

        add(panel);

        // event login — langsung buka MainGui (tanpa database dulu)
        btnLogin.addActionListener(e -> {
            // sementara, tidak pakai user dari DB, langsung buka MainGui saja
            SwingUtilities.invokeLater(() -> {
                MainGui main = new MainGui(null);  // kirim null user
                main.setVisible(true);
                this.dispose();
            });
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginFrame lf = new LoginFrame();
            lf.setVisible(true);
        });
    }
   
}
