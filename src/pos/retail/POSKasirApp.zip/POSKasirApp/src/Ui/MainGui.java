package Ui;

import Dao.ProductDao;
import Dao.TransaksiDao;
import Dao.UserDao;
import Model.TransactionItem;
import Model.User;
import Service.Service;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.print.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * MainGui - styled version to match provided mockup.
 *
 * Pastikan: Dao/Model/Service sudah ada.
 */
public class MainGui extends JFrame {

    private CardLayout cardLayout = new CardLayout();
    private JPanel cards = new JPanel(cardLayout);

    private User currentUser;
    private OrdersPanel ordersPanel;
    private ReceiptPanel receiptPanel;
    private PrintPanel printPanel;

    private Service posService = new Service();
    private UserDao userDao = new UserDao();
    private TransaksiDao transaksiDao = new TransaksiDao();
    private ProductDao productDao = new ProductDao();

    public MainGui(User user) {
        this.currentUser = user;
        setTitle("POS - Main" + (user != null ? " (" + user.getUsername() + ")" : ""));
        setSize(1220, 740);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initUI();
    }

    private void initUI() {
        // wrapper panel with dark outer border (to mimic mockup frame)
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Color.DARK_GRAY); // thin dark border around
        wrapper.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        // content area (inside border)
        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(Color.WHITE);

        // ---------------- LEFT SIDEBAR ----------------
        JPanel side = new JPanel();
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setPreferredSize(new Dimension(260, 0));
        side.setBackground(new Color(226, 226, 226)); // light grey sidebar
        side.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.GRAY));

        // top padding
        side.add(Box.createVerticalStrut(18));

        // logo box
        JPanel logoWrap = new JPanel(new GridBagLayout());
        logoWrap.setOpaque(false);
        logoWrap.setMaximumSize(new Dimension(240, 90));
        JLabel logo = new JLabel("logo", SwingConstants.CENTER);
        logo.setPreferredSize(new Dimension(180, 54));
        logo.setOpaque(true);
        logo.setBackground(Color.WHITE);
        logo.setBorder(BorderFactory.createLineBorder(new Color(110,110,110), 2));
        logo.setFont(new Font("Serif", Font.PLAIN, 20));
        logoWrap.add(logo);
        side.add(logoWrap);

        side.add(Box.createVerticalStrut(36));

        // menu buttons area (aligned top)
        JPanel menuPanel = new JPanel();
        menuPanel.setOpaque(false);
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        menuPanel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));

        JButton btnPesanan = makeIconButton("\uD83D\uDED2  Pesanan"); // cart icon unicode
        JButton btnProfil = makeIconButton("\uD83D\uDC64  Profil"); // person icon unicode

        menuPanel.add(btnPesanan);
        menuPanel.add(Box.createVerticalStrut(12));
        menuPanel.add(btnProfil);

        side.add(menuPanel);

        // filler so menu stays top (don't use glue at top - keep items near top)
        side.add(Box.createVerticalGlue());

        // ---------------- CENTER CARDS ----------------
        cards = new JPanel(cardLayout);
        cards.add(new HomePanel(), "HOME");
        ordersPanel = new OrdersPanel();
        cards.add(ordersPanel, "ORDERS");
        receiptPanel = new ReceiptPanel();
        cards.add(receiptPanel, "RECEIPT");
        printPanel = new PrintPanel();
        cards.add(printPanel, "PRINT");
        cards.add(new ProfilePanel(), "PROFILE");

        // wire buttons
        btnPesanan.addActionListener(e -> cardLayout.show(cards, "ORDERS"));
        btnProfil.addActionListener(e -> cardLayout.show(cards, "PROFILE"));

        content.add(side, BorderLayout.WEST);
        content.add(cards, BorderLayout.CENTER);

        wrapper.add(content, BorderLayout.CENTER);
        setContentPane(wrapper);

        // show HOME on startup
        cardLayout.show(cards, "HOME");
    }

    private JButton makeIconButton(String text) {
        JButton b = new JButton(text);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setFocusPainted(false);
        b.setBackground(new Color(210,210,210));
        b.setOpaque(true);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(190,190,190)),
                BorderFactory.createEmptyBorder(8,16,8,8)));
        b.setFont(b.getFont().deriveFont(Font.BOLD, 14f));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        return b;
    }

    // ---------------- HOME panel with drop-shadow text ----------------
    class HomePanel extends JPanel {
        public HomePanel() {
            setLayout(new BorderLayout());
            setBackground(Color.WHITE);

            ShadowLabel lbl = new ShadowLabel("SELAMAT DATANG, " + (currentUser != null ? currentUser.getFullName() : "KASIR") + "!");
            lbl.setFont(new Font("SansSerif", Font.BOLD, 26));
            lbl.setHorizontalAlignment(SwingConstants.CENTER);

            // center wrapper to keep text slightly left-of-center like mockup - we'll center
            JPanel wrap = new JPanel(new GridBagLayout());
            wrap.setOpaque(false);
            wrap.add(lbl);
            add(wrap, BorderLayout.CENTER);
        }
    }

    // custom label that paints a subtle drop shadow
    static class ShadowLabel extends JLabel {
        public ShadowLabel(String text) { super(text); setForeground(new Color(70,70,70)); }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            String text = getText();
            FontMetrics fm = g2.getFontMetrics(getFont());
            int x = (getWidth() - fm.stringWidth(text)) / 2;
            int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            // draw shadow
            g2.setColor(new Color(0,0,0,60));
            g2.setFont(getFont());
            g2.drawString(text, x+2, y+2);
            // draw main text
            g2.setColor(getForeground());
            g2.drawString(text, x, y);
            g2.dispose();
        }

        @Override
        public Dimension getPreferredSize() {
            String text = getText();
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(fm.stringWidth(text) + 40, fm.getHeight() + 20);
        }
    }

    // ---------------- ORDERS (search user -> show items) ----------------
    class OrdersPanel extends JPanel {
        private JTextField txtSearch;
        private JButton btnSearch;
        private JTable tblUsers;
        private DefaultTableModel usersModel;

        private JTextArea taItems;
        private JLabel lblTotal;
        private JButton btnPay, btnPrint, btnDelete;

        private Integer selectedUserId = null;
        private List<TransactionItem> currentDisplayedItems = new ArrayList<>();

        public OrdersPanel() {
            setLayout(new BorderLayout(8, 8));
            setBackground(Color.WHITE);

            // top search
            JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
            top.setBackground(Color.WHITE);
            txtSearch = new JTextField(36);
            btnSearch = new JButton("Cari");
            top.add(new JLabel("Cari nama user"));
            top.add(txtSearch);
            top.add(btnSearch);
            add(top, BorderLayout.NORTH);

            // split pane
            JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
            split.setResizeWeight(0.45);

            // left users table
            usersModel = new DefaultTableModel(new Object[]{"No.", "ID", "NAMA USER"}, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
            tblUsers = new JTable(usersModel);
            tblUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            JScrollPane spUsers = new JScrollPane(tblUsers);
            JPanel leftWrap = new JPanel(new BorderLayout());
            leftWrap.setBackground(Color.WHITE);
            leftWrap.add(new JLabel("Daftar User:"), BorderLayout.NORTH);
            leftWrap.add(spUsers, BorderLayout.CENTER);
            split.setLeftComponent(leftWrap);

            // right items + actions
            JPanel right = new JPanel(new BorderLayout(6,6));
            right.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
            right.setBackground(Color.WHITE);
            JLabel hdr = new JLabel("BARANG / JUMLAH");
            hdr.setFont(hdr.getFont().deriveFont(Font.BOLD, 14f));
            right.add(hdr, BorderLayout.NORTH);

            taItems = new JTextArea();
            taItems.setEditable(false);
            taItems.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
            JScrollPane spItems = new JScrollPane(taItems);
            spItems.setPreferredSize(new Dimension(420, 320));
            right.add(spItems, BorderLayout.CENTER);

            JPanel bottom = new JPanel();
            bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
            bottom.setOpaque(false);
            lblTotal = new JLabel("Total: Rp 0");
            lblTotal.setFont(lblTotal.getFont().deriveFont(Font.BOLD, 14f));
            lblTotal.setAlignmentX(Component.CENTER_ALIGNMENT);
            bottom.add(lblTotal);
            bottom.add(Box.createVerticalStrut(12));

            JPanel actions = new JPanel(new GridLayout(3,1,6,6));
            btnPay = new JButton("BAYAR");
            btnPrint = new JButton("CETAK");
            btnDelete = new JButton("HAPUS");
            actions.add(btnPay);
            actions.add(btnPrint);
            actions.add(btnDelete);

            bottom.add(actions);
            right.add(bottom, BorderLayout.SOUTH);

            split.setRightComponent(right);
            add(split, BorderLayout.CENTER);

            // listeners
            btnSearch.addActionListener(e -> doSearchUsers());
            txtSearch.addActionListener(e -> doSearchUsers());

            tblUsers.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                @Override public void valueChanged(ListSelectionEvent e) {
                    if (!e.getValueIsAdjusting()) {
                        int r = tblUsers.getSelectedRow();
                        if (r >= 0) {
                            Object idObj = usersModel.getValueAt(r, 1);
                            try { selectedUserId = Integer.parseInt(idObj.toString()); } catch (Exception ex) { selectedUserId = null; }
                        } else selectedUserId = null;
                        loadItemsForSelectedUser();
                    }
                }
            });

            btnPay.addActionListener(e -> {
                if (selectedUserId == null) { JOptionPane.showMessageDialog(OrdersPanel.this, "Pilih user terlebih dahulu."); return; }
                if (currentDisplayedItems.isEmpty()) { JOptionPane.showMessageDialog(OrdersPanel.this, "Tidak ada item untuk dibayar."); return; }
                double total = currentDisplayedItems.stream().mapToDouble(TransactionItem::getSubtotal).sum();
                receiptPanel.showReceipt(currentDisplayedItems, total);
                cardLayout.show(cards, "RECEIPT");
            });

            btnPrint.addActionListener(e -> {
                if (selectedUserId == null) { JOptionPane.showMessageDialog(OrdersPanel.this, "Pilih user terlebih dahulu."); return; }
                if (currentDisplayedItems.isEmpty()) { JOptionPane.showMessageDialog(OrdersPanel.this, "Tidak ada item untuk dicetak."); return; }
                double total = currentDisplayedItems.stream().mapToDouble(TransactionItem::getSubtotal).sum();
                String receipt = buildReceiptString(currentDisplayedItems, total, 0);
                printPanel.setReceipt(receipt);
                cardLayout.show(cards, "PRINT");
            });

            btnDelete.addActionListener(e -> {
                if (selectedUserId == null) { JOptionPane.showMessageDialog(OrdersPanel.this, "Pilih user terlebih dahulu."); return; }
                int confirm = JOptionPane.showConfirmDialog(OrdersPanel.this, "Hapus semua item user ini dari cart?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean ok = transaksiDao.clearActiveCartByUser(selectedUserId);
                    if (ok) {
                        loadItemsForSelectedUser();
                        JOptionPane.showMessageDialog(OrdersPanel.this, "Cart dihapus.");
                    } else {
                        JOptionPane.showMessageDialog(OrdersPanel.this, "Gagal menghapus cart (cek log).");
                    }
                }
            });

            refreshUsersTable(new ArrayList<>());
        }

        private void doSearchUsers() {
            String term = txtSearch.getText().trim();
            usersModel.setRowCount(0);
            if (term.isEmpty()) return;
            List<User> users = userDao.findByName(term);
            if (users == null || users.isEmpty()) {
                JOptionPane.showMessageDialog(this, "User tidak ditemukan.");
                return;
            }
            int no = 1;
            for (User u : users) {
                String name = (u.getFullName() != null && !u.getFullName().isEmpty()) ? u.getFullName() : u.getUsername();
                usersModel.addRow(new Object[]{no++, u.getId(), name});
            }
            if (usersModel.getRowCount() > 0) tblUsers.setRowSelectionInterval(0,0);
        }

        private void refreshUsersTable(List<User> users) {
            usersModel.setRowCount(0);
            int no = 1;
            for (User u : users) usersModel.addRow(new Object[]{no++, u.getId(), u.getFullName() != null ? u.getFullName() : u.getUsername()});
        }

        private void loadItemsForSelectedUser() {
            taItems.setText("");
            lblTotal.setText("Total: Rp 0");
            currentDisplayedItems.clear();
            if (selectedUserId == null) return;
            List<TransactionItem> items = transaksiDao.findActiveItemsByUser(selectedUserId);
            if (items == null || items.isEmpty()) {
                taItems.setText("Tidak ada barang / cart kosong untuk user ini.");
                return;
            }
            StringBuilder sb = new StringBuilder();
            double total = 0;
            for (TransactionItem it : items) {
                sb.append("- ").append(it.getName()).append("  JUMLAH: ").append(it.getQty()).append("  Rp ").append((long) it.getSubtotal()).append("\n");
                total += it.getSubtotal();
                currentDisplayedItems.add(it);
            }
            taItems.setText(sb.toString());
            lblTotal.setText("Total: Rp " + new DecimalFormat("#,###").format(total));
        }
    }

    // ---------------- RECEIPT ----------------
    class ReceiptPanel extends JPanel {
        private JTextArea taSummary;
        private JTextField txtBayar;
        private JTextField txtKembali;
        private JLabel lblTotal;
        private JButton btnConfirmPrint;
        private JButton btnCancel;

        private List<TransactionItem> currentCart = new ArrayList<>();
        private double currentTotal = 0;

        public ReceiptPanel() {
            setLayout(new GridBagLayout());
            JPanel card = new JPanel();
            card.setPreferredSize(new Dimension(380, 460));
            card.setBackground(new Color(245, 245, 245));
            card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                    BorderFactory.createEmptyBorder(12, 12, 12, 12)));
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

            taSummary = new JTextArea();
            taSummary.setEditable(false);
            taSummary.setBackground(new Color(250, 250, 250));
            taSummary.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            taSummary.setMaximumSize(new Dimension(340, 260));
            taSummary.setFont(new Font("Monospaced", Font.PLAIN, 12));

            lblTotal = new JLabel("TOTAL: Rp 0");
            lblTotal.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblTotal.setFont(new Font("SansSerif", Font.BOLD, 14));
            lblTotal.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

            txtBayar = new JTextField();
            txtBayar.setMaximumSize(new Dimension(340, 28));
            txtBayar.setAlignmentX(Component.CENTER_ALIGNMENT);
            txtBayar.setBorder(BorderFactory.createTitledBorder("Bayar"));

            txtKembali = new JTextField();
            txtKembali.setMaximumSize(new Dimension(340, 28));
            txtKembali.setAlignmentX(Component.CENTER_ALIGNMENT);
            txtKembali.setBorder(BorderFactory.createTitledBorder("Kembalian"));
            txtKembali.setEditable(false);

            btnConfirmPrint = new JButton("KONFIRMASI & CETAK STRUK");
            btnConfirmPrint.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnCancel = new JButton("BATAL");
            btnCancel.setAlignmentX(Component.CENTER_ALIGNMENT);

            card.add(Box.createVerticalStrut(6));
            card.add(taSummary);
            card.add(Box.createVerticalStrut(8));
            card.add(lblTotal);
            card.add(Box.createVerticalStrut(6));
            card.add(txtBayar);
            card.add(Box.createVerticalStrut(6));
            card.add(txtKembali);
            card.add(Box.createVerticalStrut(10));
            card.add(btnConfirmPrint);
            card.add(Box.createVerticalStrut(6));
            card.add(btnCancel);

            add(card);

            txtBayar.addKeyListener(new KeyAdapter() { public void keyReleased(KeyEvent e) { updateKembalian(); } });

            btnCancel.addActionListener(e -> cardLayout.show(cards, "ORDERS"));

            btnConfirmPrint.addActionListener(e -> {
                String s = txtBayar.getText().replaceAll("[^0-9.]", "");
                double bayar;
                try { bayar = Double.parseDouble(s); } catch (Exception ex) { JOptionPane.showMessageDialog(ReceiptPanel.this, "Masukkan nominal bayar valid."); return; }
                if (bayar < currentTotal) { JOptionPane.showMessageDialog(ReceiptPanel.this, "Uang diterima kurang dari total."); return; }

                try {
                    int cashierId = currentUser != null ? currentUser.getId() : 1;
                    posService.processCheckout(cashierId, currentCart, 0.0, 0.0, "TUNAI", bayar);

                    String receipt = buildReceiptString(currentCart, currentTotal, bayar);
                    if (printPanel != null) printPanel.setReceipt(receipt);

                    cardLayout.show(cards, "PRINT");
                    JOptionPane.showMessageDialog(ReceiptPanel.this, "Transaksi tersimpan. Preview struk ditampilkan.");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(ReceiptPanel.this, "Gagal menyimpan transaksi: " + ex.getMessage());
                }
            });
        }

        public void showReceipt(List<TransactionItem> cart, double total) {
            this.currentCart = new ArrayList<>();
            for (TransactionItem it : cart) this.currentCart.add(new TransactionItem(it.getProductId(), it.getSku(), it.getName(), it.getQty(), it.getUnitPrice()));
            this.currentTotal = total;

            StringBuilder sb = new StringBuilder();
            for (TransactionItem it : currentCart) {
                sb.append(it.getName()).append(" x ").append(it.getQty()).append("   Rp ").append((long) it.getSubtotal()).append("\n");
            }
            sb.append("\n");
            sb.append("TOTAL: Rp ").append((long) currentTotal).append("\n");
            taSummary.setText(sb.toString());
            lblTotal.setText("TOTAL: Rp " + String.format("%,d", (long) currentTotal));
            txtBayar.setText("");
            txtKembali.setText("");
        }

        private void updateKembalian() {
            String s = txtBayar.getText().replaceAll("[^0-9.]", "");
            try {
                double bayar = s.isEmpty() ? 0 : Double.parseDouble(s);
                double kembali = bayar - currentTotal;
                txtKembali.setText(String.format("%,.0f", kembali >= 0 ? kembali : 0));
            } catch (Exception e) {
                txtKembali.setText("0");
            }
        }
    }

    // ---------------- PRINT ----------------
    class PrintPanel extends JPanel {
        private JTextArea ta;
        private JButton btnPrintNow;
        private JButton btnSelesai;

        public PrintPanel() {
            setLayout(new BorderLayout());
            ta = new JTextArea();
            ta.setFont(new Font("Monospaced", Font.PLAIN, 12));
            ta.setEditable(false);
            add(new JScrollPane(ta), BorderLayout.CENTER);

            JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
            btnPrintNow = new JButton("Cetak Sekarang");
            btnSelesai = new JButton("Selesai");
            bottom.add(btnPrintNow);
            bottom.add(btnSelesai);
            add(bottom, BorderLayout.SOUTH);

            btnPrintNow.addActionListener(e -> printReceiptNow());
            btnSelesai.addActionListener(e -> {
                cardLayout.show(cards, "ORDERS");
            });
        }

        public void setReceipt(String r) { ta.setText(r); }
        public String getReceiptText() { return ta.getText(); }
    }

    // ---------------- PROFILE ----------------
    class ProfilePanel extends JPanel {
        public ProfilePanel() {
            setLayout(new BorderLayout());
            setBackground(Color.WHITE);
            add(Box.createRigidArea(new Dimension(20,0)), BorderLayout.WEST);

            JPanel centerWrap = new JPanel(new GridBagLayout());
            centerWrap.setOpaque(false);
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.CENTER;

            JPanel card = new JPanel();
            card.setPreferredSize(new Dimension(520, 420));
            card.setBackground(Color.WHITE);
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

            JLabel avatarLabel = new JLabel();
            avatarLabel.setPreferredSize(new Dimension(110, 110));
            avatarLabel.setMaximumSize(new Dimension(110, 110));
            avatarLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            avatarLabel.setIcon(createCircleIcon(110, new Color(240,240,240), Color.DARK_GRAY));
            avatarLabel.setBorder(BorderFactory.createEmptyBorder(0,0,16,0));
            card.add(avatarLabel);

            card.add(Box.createVerticalStrut(10));

            JButton nameBtn = new JButton(currentUser != null && currentUser.getFullName() != null ? currentUser.getFullName() : "NAMA KASIR");
            styleInputLikeButton(nameBtn);
            nameBtn.setEnabled(false);
            card.add(nameBtn);
            card.add(Box.createVerticalStrut(10));

            JButton passBtn = new JButton("PASSWORD KASIR");
            styleInputLikeButton(passBtn);
            passBtn.setEnabled(false);
            card.add(passBtn);
            card.add(Box.createVerticalStrut(20));

            JButton logoutBtn = new JButton("LOGOUT");
            logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoutBtn.setMaximumSize(new Dimension(220, 40));
            logoutBtn.setPreferredSize(new Dimension(220, 40));
            logoutBtn.setFocusPainted(false);
            logoutBtn.setBackground(new Color(237, 140, 140));
            logoutBtn.setForeground(Color.WHITE);
            logoutBtn.setOpaque(true);
            logoutBtn.setBorder(BorderFactory.createEmptyBorder(8,16,8,16));
            logoutBtn.setFont(logoutBtn.getFont().deriveFont(Font.BOLD, 14f));
            logoutBtn.addActionListener(e -> {
                SwingUtilities.invokeLater(() -> {
                    try {
                        LoginFrame lf = new LoginFrame();
                        lf.setVisible(true);
                    } catch (Exception ex) { ex.printStackTrace(); }
                    MainGui.this.dispose();
                });
            });

            card.add(logoutBtn);

            centerWrap.add(card, gbc);
            add(centerWrap, BorderLayout.CENTER);
        }

        private void styleInputLikeButton(JButton b) {
            b.setAlignmentX(Component.CENTER_ALIGNMENT);
            b.setMaximumSize(new Dimension(360, 36));
            b.setPreferredSize(new Dimension(360, 36));
            b.setFocusPainted(false);
            b.setBackground(new Color(225,225,225));
            b.setOpaque(true);
            b.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(210,210,210)),
                    BorderFactory.createEmptyBorder(6,12,6,12)));
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setFont(b.getFont().deriveFont(Font.PLAIN, 13f));
        }

        private Icon createCircleIcon(int size, Color bg, Color fg) {
            BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(bg);
            g.fillOval(0, 0, size, size);
            g.setColor(fg);
            int headR = size/4;
            int headX = size/2 - headR/2;
            int headY = size/4 - headR/4;
            g.fillOval(headX, headY, headR, headR);
            int bodyW = size/2;
            int bodyH = size/3;
            int bodyX = size/2 - bodyW/2;
            int bodyY = size/2;
            g.fillRoundRect(bodyX, bodyY, bodyW, bodyH, 20, 20);
            g.dispose();
            return new ImageIcon(img);
        }
    }

    // ---------------- utilities ----------------
    private String buildReceiptString(List<TransactionItem> cart, double total, double bayar) {
        StringBuilder sb = new StringBuilder();
        sb.append("TOKO SEHAT\n");
        sb.append("Kasir: ").append(currentUser != null ? currentUser.getFullName() : "Kasir").append("\n");
        sb.append("--------------------------------\n");
        for (TransactionItem it : cart) {
            sb.append(it.getQty()).append(" x ").append(it.getName()).append("  Rp ").append((long) it.getUnitPrice()).append("\n");
        }
        sb.append("--------------------------------\n");
        sb.append("TOTAL: Rp ").append((long) total).append("\n");
        if (bayar > 0) {
            sb.append("TUNAI: Rp ").append((long) bayar).append("\n");
            sb.append("KEMBALIAN: Rp ").append((long) (bayar - total)).append("\n");
        }
        sb.append("\nTerima kasih!");
        return sb.toString();
    }

    public void printReceiptNow() {
        PrintPanel p = printPanel;
        if (p == null) { JOptionPane.showMessageDialog(this, "Tidak ada yang dicetak."); return; }
        String text = p.getReceiptText();
        if (text == null || text.trim().isEmpty()) { JOptionPane.showMessageDialog(this, "Struk kosong."); return; }

        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Struk Pembelian");
        job.setPrintable((graphics, pageFormat, pageIndex) -> {
            if (pageIndex > 0) return Printable.NO_SUCH_PAGE;
            Graphics2D g2 = (Graphics2D) graphics;
            g2.translate((int) pageFormat.getImageableX(), (int) pageFormat.getImageableY());
            g2.setFont(new Font("Monospaced", Font.PLAIN, 10));
            int y = 0;
            for (String line : text.split("\n")) {
                y += 12;
                g2.drawString(line, 0, y);
            }
            return Printable.PAGE_EXISTS;
        });

        boolean doPrint = job.printDialog();
        if (doPrint) {
            try { job.print(); }
            catch (PrinterException ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(this, "Gagal mencetak: " + ex.getMessage()); }
        }
    }

    // ---------------- main untuk testing ----------------
    public static void main(String[] args) {
        Model.User test = new Model.User();
        try { test.setId(1); } catch (Exception ignored) {}
        try { test.setUsername("kasir"); } catch (Exception ignored) {}
        try { test.setFullName("KASIR UTAMA"); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> {
            MainGui g = new MainGui(test);
            g.setVisible(true);
        });
    }
}
