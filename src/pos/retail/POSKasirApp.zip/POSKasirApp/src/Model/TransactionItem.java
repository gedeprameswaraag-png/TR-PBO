package Model;

public class TransactionItem {
    private int productId;
    private String sku;
    private String name;
    private int qty;
    private double unitPrice;
    private double discount;
    private double subtotal;

    public TransactionItem() {}

    public TransactionItem(int productId, String sku, String name, int qty, double unitPrice) {
        this.productId = productId;
        this.sku = sku;
        this.name = name;
        this.qty = qty;
        this.unitPrice = unitPrice;
        this.discount = 0;
        recalc();
    }

    private void recalc() {
        this.subtotal = (unitPrice * qty) - discount;
    }

    public int getProductId() { return productId; }
    public String getSku() { return sku; }
    public String getName() { return name; }
    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; recalc(); }
    public double getUnitPrice() { return unitPrice; }
    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; recalc(); }
    public double getSubtotal() { return subtotal; }
}
