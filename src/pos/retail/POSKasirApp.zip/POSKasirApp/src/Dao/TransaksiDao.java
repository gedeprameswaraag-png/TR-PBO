package Dao;

import Model.TransactionItem;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TransaksiDao {
    public long insertTransaction(Connection conn, String transNo, int userId, double total, double tax, double discount, String paymentMethod, double cashReceived, double changeAmount, List<TransactionItem> items) throws SQLException {
        String insertTx = "INSERT INTO transactions (trans_no, user_id, total, tax, discount, payment_method, cash_received, change_amount, created_at) VALUES (?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(insertTx, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, transNo);
            ps.setInt(2, userId);
            ps.setDouble(3, total);
            ps.setDouble(4, tax);
            ps.setDouble(5, discount);
            ps.setString(6, paymentMethod);
            ps.setDouble(7, cashReceived);
            ps.setDouble(8, changeAmount);
            ps.setString(9, LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                long txId = rs.getLong(1);
                insertItems(conn, txId, items);
                return txId;
            } else {
                throw new SQLException("Gagal insert transaksi");
            }
        }
    }

    private void insertItems(Connection conn, long txId, List<TransactionItem> items) throws SQLException {
        String insertItem = "INSERT INTO transaction_items (transaction_id, product_id, sku, name, qty, unit_price, discount, subtotal) VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(insertItem)) {
            for (TransactionItem it : items) {
                ps.setLong(1, txId);
                ps.setInt(2, it.getProductId());
                ps.setString(3, it.getSku());
                ps.setString(4, it.getName());
                ps.setInt(5, it.getQty());
                ps.setDouble(6, it.getUnitPrice());
                ps.setDouble(7, it.getDiscount());
                ps.setDouble(8, it.getSubtotal());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    public boolean clearActiveCartByUser(Integer selectedUserId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<TransactionItem> findActiveItemsByUser(Integer selectedUserId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
