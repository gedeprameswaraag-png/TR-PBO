package Dao;

import Model.Product;
import Util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProductDao {

    public ProductDao() {
    }

    
    public List<Product> findByName(String term) {
        List<Product> result = new ArrayList<>();
        String sql = "SELECT id, sku, name, price, stock FROM products WHERE name LIKE ? ORDER BY name LIMIT 50";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + term + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product p = new Product();
                    p.setId(rs.getInt("id"));
                    p.setSku(rs.getString("sku"));
                    p.setName(rs.getString("name"));
                    p.setPrice(rs.getDouble("price"));
                    p.setStock(rs.getInt("stock"));
                    result.add(p);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); 
        }
        return result;
    }

    
    public int reduceStock(Connection conn, int productId, int qty) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public Product findBySku(String sku) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
