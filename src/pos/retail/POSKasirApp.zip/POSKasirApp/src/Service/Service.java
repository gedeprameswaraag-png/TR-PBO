package Service;

import Dao.ProductDao;
import Dao.TransaksiDao;
import Model.TransactionItem;
import Util.DBConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class Service {
    private ProductDao productDao = new ProductDao();
    private TransaksiDao transaksiDao = new TransaksiDao();

    // proses checkout: transactional
    public void processCheckout(int userId, List<TransactionItem> items, double tax, double discount, String paymentMethod, double cashReceived) throws SQLException {
        double total = 0;
        for (TransactionItem it : items) total += it.getSubtotal();
        total = total + tax - discount;
        double change = cashReceived - total;
        if (cashReceived < total) throw new IllegalArgumentException("Tunai yang diberikan kurang dari total");

        try (Connection conn = DBConnection.getConnection()) {
            try {
                conn.setAutoCommit(false);

                // reduce stock
                for (TransactionItem it : items) {
                    int updated = productDao.reduceStock(conn, it.getProductId(), it.getQty());
                    if (updated == 0) throw new SQLException("Stok tidak cukup untuk produk id=" + it.getProductId());
                }

                // buat nomer transaksi unik
                String transNo = "TX" + UUID.randomUUID().toString().replaceAll("-", "").substring(0,12).toUpperCase();

                transaksiDao.insertTransaction(conn, transNo, userId, total, tax, discount, paymentMethod, cashReceived, change, items);

                conn.commit();
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }
}
